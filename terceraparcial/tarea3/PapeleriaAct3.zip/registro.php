<?php
session_start();

include 'db.php';

// Procesar la creación de un nuevo producto
if (isset($_POST['add_registro'])) {
    $nombre = $_POST['nombre'];
    $cantidad = $_POST['cantidad'];
    $precio = $_POST['precio']; 
    $user_id = $_SESSION['user_id'];

    // Insertar el nuevo producto en la base de datos
    $query = $pdo->prepare("
        INSERT INTO REGISTRO (ID, NOMBRE, CORREO, PASSWORD, USUARIO_TIPO)
        VALUES (:ID, :NOMBRE, :CORREO, :PASSWORD, :USUARIO_TIPO)
    ");
    $query->execute([
        'ID' => $ID,
        'NOMBRE' => $NOMBRE,
        'CORREO' => $CORREO,
        'PASSWORD' => $PASSWORD,
        'USUARIO_TIPO' => $USUARIO_TIPO
    ]);

    // Redirigir a la lista de personajes
    header('Location:  vendedorinicio.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Registro </title>
</head>
<body>
    <div class="registro">
        <div class="resgistro-tit">Registrarse</div>
        <form method="POST">
            <label for="name">Nombre:</label> 
            <input type="text" id="name" name="NOMBRE" required> <br><br>

            <label for="email">Correo Electronico:</label> 
            <input type="email" id="email" name="CORREO" required><br><br>

            <label for="password">Password:</label> 
            <input type="password" id="password" name="PASSWORD" required><br><br>


            <label for="tipo">Usuario Tipo:</label> 
            <select id="tipo" name="USUARIO_TIPO">
                <option value="Admin">Administrador</option>
                <option value="Vendedor">Vendedor</option>
            </select> <br><br>
           
            <button type="submit" name="add_registro">Registrarse</button>
        </form>
        <p>¿Ya tienes una cuenta? <a href="index.php">Inicia sesion aqui</a></p>
    </div>
</body>
</html>
