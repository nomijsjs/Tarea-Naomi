<?php
session_start();
if (isset($_POST['login'])) {
    // Aquí iría la conexión a la base de datos (ejemplo con MySQL)
    include 'db.php'; // Archivo de conexión a la base de datos

    $email = $_POST['correo'];
    $password = $_POST['password'];

    // Consulta a la base de datos para verificar el usuario
    $query = $pdo->prepare("SELECT * FROM registro WHERE email = :email");
    $query->execute(['email' => $email]);
    $user = $query->fetch();

    // Verificación de contraseña    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header('Location: registro.html');
        exit();
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Iniciar Sesion</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="inicio_sesion"> 
       
            <div class="titulopap">Papeleria Cetis 84</div>
            <div class="textab">Bienvenido seas, ingresa a continuacion</div> <br><br>
        <center> <a href="adminInicio.html"><button>Administrador</button></a><br><br> </center> 
         <center>  <a href="vendedorInicio.html"><button>Vendedor</button></a><br><br> </center> 
     



        <center><div class="creado">
            CREADO POR:

            <div class="nombres">Castillo Trinidad Naomi Desiree y Flores Estrada Katya Naomi</div>
         </div>  </center> 
</div>
</body>
</html>
