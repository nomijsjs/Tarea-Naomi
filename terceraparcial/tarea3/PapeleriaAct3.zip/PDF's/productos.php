<?php
require('fpdf186/fpdf.php');

// Conexión a la base de datos
$host = "localhost";
$user = "root";
$password = "";
$db = "papeleria";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta a la base de datos
$sql = "SELECT * FROM registro_productos";
$result = $conn->query($sql);

// Crear PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Encabezado de la tabla
$pdf->Cell(20, 10, 'ID', 1, 0, 'C');
$pdf->Cell(70, 10, 'Nombre', 1, 0, 'C');
$pdf->Cell(30, 10, 'Cantidad', 1, 0, 'C');
$pdf->Cell(30, 10, 'Precio', 1, 1, 'C');

// Datos de la tabla
$pdf->SetFont('Arial', '', 12);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(20, 10, $row['ID_P'], 1, 0, 'C');
        $pdf->Cell(70, 10, $row['NOMBRE_P'], 1, 0, 'C');
        $pdf->Cell(30, 10, $row['CANTIDAD'], 1, 0, 'C');
        $pdf->Cell(30, 10, $row['PRECIO'], 1, 1, 'C');
    }
} else {
    $pdf->Cell(0, 10, 'No hay datos disponibles', 1, 1, 'C');
}

// Salida del PDF
$pdf->Output();



//hacer coneccion a base de datos 
//hacer la consulta a l atabla de peodictos



//creamos un nueovo objeto de pdf
//creamos una nueva hoja pdf
//filtrar conv un if y un else que no se enbcontraron registros
//usar un ciclo foreach
//pdf cell 
//salto de linea ,0,1) al final de cada reitro 
//cerre a pd f


?>




















