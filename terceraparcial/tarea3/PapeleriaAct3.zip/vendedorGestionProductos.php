<?php
session_start();

include 'db.php';

// Procesar la creación de un nuevo producto
if (isset($_POST['add_producto'])) {
    $nombre = $_POST['nombre'];
    $cantidad = $_POST['cantidad'];
    $precio = $_POST['precio']; 
    $user_id = $_SESSION['user_id'];

    // Insertar el nuevo producto en la base de datos
    $query = $pdo->prepare("
        INSERT INTO REGISTRO_PRODUCTOS (ID_P, NOMBRE_P, CANTIDAD, PRECIO)
        VALUES (:ID_P, :NOMBRE_P, :CANTIDAD, :PRECIO)
    ");
    $query->execute([
        'ID_P' => $ID_P,
        'NOMBRE_P' => $NOMBRE_P,
        'CANTIDAD' => $CANTIDAD,
        'PRECIO' => $PRECIO
    ]);

    // Redirigir
    header('Location:  vendedorinicio.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tabla de Productos</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="lista-productos">
    <div class="tit-producto">Registro de Productos</div>
    <form method="POST">

<center>
    <label for="nombre">Nombre del Producto:</label>
    <input type="text" id="nombre" placeholder="Ej. Producto A"> <br><br>
    <label for="cantidad">Cantidad:</label>
    <input type="number" id="cantidad" placeholder="Ej. 10"> <br><br>
    <label for="precio">Precio:</label>
    <input  placeholder="Ej. 20.50"> <br><br> </center>


  <center>   <button class="agregarProducto"  type="submit" name="add_producto" >Agregar Producto</button> 
 
    <a href="vendendorGestion.html"><button class="regresar">REGRESAR</button></a> </center>
    </form>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="productTable">
            
        </tbody>
    </table>

</div>
</body>
